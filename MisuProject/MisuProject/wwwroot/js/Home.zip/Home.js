﻿document.addEventListener("DOMContentLoaded", () => {
    const logoutIcon = document.getElementById('logouts');

    logoutIcon.addEventListener('click', (e) => {
        e.preventDefault();
        localStorage.clear();
        alert('local Storage Cleared')
        window.location.href = 'index.html';
    });
});
